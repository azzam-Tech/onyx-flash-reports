from flask import Flask, request, jsonify, render_template
import os
import qrcode
import base64
from datetime import datetime
from dotenv import load_dotenv
import oracledb

load_dotenv()

app = Flask(__name__)

# Initialize Oracle Client with Thick Mode based on Env
lib_dir = os.getenv("ORA_LIB_DIR", r"C:\oracle\instantclient\instantclient_23_0")
try:
    oracledb.init_oracle_client(lib_dir=lib_dir)
except Exception as e:
    print("Warning: Oracle client init failed. It might be already initialized or path is wrong.", e)

def get_conn():
    return oracledb.connect(
        user=os.getenv("DB_USER", "RPT_USER"),
        password=os.getenv("DB_PASS", "RPT_USER"),
        dsn=os.getenv("ORA_DSN", "100.100.1.100:1521/ORCL")
    )

def generate_tlv(tag, value):
    if isinstance(value, str):
        value_bytes = value.encode('utf-8')
    else:
        value_bytes = value
    return bytes([tag, len(value_bytes)]) + value_bytes

def generate_zatca_qr_base64(seller_name, vat_number, timestamp, total_amount, vat_amount):
    tlv1 = generate_tlv(1, seller_name)
    tlv2 = generate_tlv(2, vat_number)
    tlv3 = generate_tlv(3, timestamp)
    tlv4 = generate_tlv(4, str(total_amount))
    tlv5 = generate_tlv(5, str(vat_amount))
    full_tlv = tlv1 + tlv2 + tlv3 + tlv4 + tlv5
    return base64.b64encode(full_tlv).decode('utf-8')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/invoice/<path:bill_no>')
def get_invoice(bill_no):
    try:
        with get_conn() as con:
            with con.cursor() as cur:
                # Get Invoice Master Data
                cur.execute("""
                    SELECT 
                        m.BILL_NO, 
                        TO_CHAR(m.BILL_DATE, 'DD/MM/YYYY'), 
                        TO_CHAR(m.AD_DATE, 'HH:MI:SS AM'),
                        m.BILL_AMT,
                        NVL(m.VAT_AMT, 0) as VAT_AMT,
                        NVL(m.C_NAME, c.C_A_NAME) as C_NAME,
                        m.BILL_DATE,
                        m.BILL_DOC_TYPE,
                        c.BUILDING_NO,
                        c.STREET,
                        c.DSTRCT_NM,
                        c.C_BOX_CODE,
                        c.ADD_NO,
                        c.C_TAX_CODE,
                        c.CR_NO,
                        c.CSTMR_IDNTFR,
                        m.TAX_BILL_TYP,
                        TO_CHAR(m.AD_DATE, 'HH24:MI:SS')
                    FROM IAS20261.IAS_BILL_MST m
                    LEFT JOIN IAS20261.CUSTOMER c ON c.C_CODE = m.C_CODE
                    WHERE m.BILL_NO = :1
                """, [bill_no])
                
                mst_row = cur.fetchone()
                if not mst_row:
                    return jsonify({"error": "الفاتورة غير موجودة"}), 404
                    
                b_no, b_date, b_time, b_amt, v_amt, c_name, raw_date, doc_type, c_building, c_street, c_district, c_postal, c_add_no, c_vat, c_crn, c_other_id, tax_bill_typ, time_24h = mst_row
                
                # Payment method string
                pay_method = "نقد / Cash" if str(doc_type) == '1' else "آجل / Credit"
                
                # Fetch Seller Data (Branch)
                cur.execute("""
                    SELECT 
                        CMP_LNAME || ' - ' || BRN_LNAME as S_NAME,
                        BUILDING_NO,
                        STREET,
                        DSTRCT_NM,
                        POSTAL_CODE,
                        ADD_NO,
                        BRN_TAX_CODE,
                        RC_CODE,
                        BRN_IDNTFR
                    FROM IAS20261.S_BRN 
                    WHERE BRN_NO = 1
                """)
                s_row = cur.fetchone()
                if s_row:
                    s_name, s_building, s_street, s_district, s_postal, s_add_no, s_vat, s_crn, s_other_id = s_row
                else:
                    s_name = s_building = s_street = s_district = s_postal = s_add_no = s_vat = s_crn = s_other_id = ""

                # Determine Invoice Type from TAX_BILL_TYP
                # 2 = Standard Tax Invoice (B2B)
                # 1 = Simplified Tax Invoice (B2C)
                if str(tax_bill_typ) == '2':
                    inv_type_ar = "فاتورة ضريبية"
                    inv_type_en = "Tax Invoice"
                else:
                    inv_type_ar = "فاتورة ضريبية مبسطة"
                    inv_type_en = "Simplified Tax Invoice"
                
                # Fetch Details
                cur.execute("""
                    SELECT 
                        d.I_CODE,
                        NVL(m.I_NAME, 'صنف غير معروف'),
                        d.I_QTY,
                        d.I_PRICE,
                        NVL(d.DIS_AMT, 0),
                        NVL(d.VAT_AMT, 0),
                        (d.I_QTY * d.I_PRICE) - NVL(d.DIS_AMT, 0) + NVL(d.VAT_AMT, 0) as TOT_AMT
                    FROM IAS20261.IAS_BILL_DTL d
                    LEFT JOIN IAS20261.IAS_ITM_MST m ON d.I_CODE = m.I_CODE
                    WHERE d.BILL_NO = :1
                """, [bill_no])
                
                items = []
                for r in cur.fetchall():
                    items.append({
                        "item_id": r[0],
                        "item_name": r[1],
                        "quantity": r[2],
                        "amount": r[3],
                        "discount": r[4],
                        "tax": r[5],
                        "total_due": r[6]
                    })
                
                # Generate QR Code
                seller_name_qr = s_name or "مؤسسة عاصمة المجد للتجارة - سرين"
                vat_no_qr = s_vat or "302145687600003"
                
                # Format timestamp for ZATCA (ISO 8601)
                try:
                    time_str = str(time_24h) if time_24h else "00:00:00"
                    if len(time_str) == 5: # HH:MM
                        time_str += ":00"
                    dt_str = raw_date.strftime('%Y-%m-%d') + "T" + time_str + "Z"
                except:
                    dt_str = "2026-08-08T18:09:00Z"
                
                total_with_tax = float(b_amt) + float(v_amt)
                
                qr_base64 = generate_zatca_qr_base64(
                    seller_name_qr, 
                    vat_no_qr, 
                    dt_str, 
                    "{:.2f}".format(total_with_tax), 
                    "{:.2f}".format(float(v_amt))
                )
                
                try:
                    from tafqeet import do_tafqeet
                    amount_in_words = do_tafqeet(total_with_tax)
                except:
                    amount_in_words = ""

                # Dummy Data for Seller/Buyer Addresses for now
                return jsonify({
                    "invoice_no": b_no,
                    "invoice_date": b_date,
                    "invoice_time": b_time,
                    "due_date": b_date,
                    "payment_method": pay_method,
                    "invoice_type_ar": inv_type_ar,
                    "invoice_type_en": inv_type_en,
                    "amount_in_words": amount_in_words,
                    "seller": {
                        "name": s_name,
                        "building": s_building,
                        "street": s_street,
                        "district": s_district,
                        "city": "الرياض",
                        "country": "المملكة العربية السعودية",
                        "postal_code": s_postal,
                        "additional_no": s_add_no,
                        "vat_no": s_vat,
                        "crn": s_crn,
                        "other_id": s_other_id
                    },
                    "buyer": {
                        "name": c_name or "عميل نقدي",
                        "building": c_building or "",
                        "street": c_street or "",
                        "district": c_district or "",
                        "city": "",
                        "country": "",
                        "postal_code": c_postal or "",
                        "additional_no": c_add_no or "",
                        "vat_no": c_vat or "",
                        "crn": c_crn or "",
                        "other_id": c_other_id or ""
                    },
                    "items": items,
                    "totals": {
                        "total_qty": sum(i["quantity"] for i in items),
                        "total_excluding_vat": b_amt,
                        "discount": sum(i["discount"] for i in items),
                        "charges": 0.00,
                        "total_taxable": b_amt,
                        "tax": v_amt,
                        "total_with_tax": total_with_tax,
                        "text": "ثلاثة عشر ألف و مئتين و خمسة و عشرون ريال سعودي" # We can add Tafqeet later
                    },
                    "qr_base64": qr_base64
                })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
